﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto3Camadas.Code.DTO
{
    class LoginDTO
    {
        private int _id;
        private string _Senha;
        private string _Email;

       
        public int Id { get => _id; set => _id = value; }
        public string Email { get => _Email; set => _Email = value; }
        public string Senha { get => _Senha; set => _Senha = value; }

    }
}
