﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto3Camadas.Code.DTO
{
    class ProdutoDTO
    {
        
        private int _id;
        private string _Nome;
        private string _Genero;

        
        public int Id { get => _id; set => _id = value; }
        public string Nome { get => _Nome; set => _Nome = value; }
        public string Genero { get => _Genero; set => _Genero = value; }
    }
}
