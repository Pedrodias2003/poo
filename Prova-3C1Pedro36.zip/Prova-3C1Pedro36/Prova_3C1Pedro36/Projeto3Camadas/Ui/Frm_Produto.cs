﻿using System;
using System.Windows.Forms;


using Projeto3Camadas.Code.BLL; 
using Projeto3Camadas.Code.DTO; 
namespace Projeto3Camadas.Ui
{
    public partial class Frm_Produto : Form
    {

        ProdutoBLL Produtobll = new ProdutoBLL();
        ProdutoDTO Produtodto = new ProdutoDTO();

        public Frm_Produto()
        {
            InitializeComponent();
        }

        private void btn_Cadastrar_Click(object sender, EventArgs e)
        {
            
            Produtodto.Nome = txtNome.Text;
            Produtodto.Genero = txtGenero.Text;

            
            Produtobll.Inserir(Produtodto);

            
            MessageBox.Show("Cadastrado com sucesso!", "Produto", MessageBoxButtons.OK, MessageBoxIcon.Information);

           
            txtId.Clear();
            txtNome.Clear();
            txtGenero.Clear();
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {

            
            Produtodto.Id = int.Parse(txtId.Text);
            Produtodto.Nome = txtNome.Text;
            Produtodto.Genero = txtGenero.Text;

            
            Produtobll.Editar(Produtodto);

            
            MessageBox.Show("Alterado com sucesso!", "Produto", MessageBoxButtons.OK, MessageBoxIcon.Information);


            Produtobll.Listar();

            
            txtId.Clear();
            txtNome.Clear();
            txtGenero.Clear();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {

            Produtodto.Id = int.Parse(txtId.Text);


            Produtobll.Excluir(Produtodto);

            
            MessageBox.Show("Excluido com sucesso!", "Produto", MessageBoxButtons.OK, MessageBoxIcon.Information);


            Produtobll.Listar();

            
            txtId.Clear();
            txtNome.Clear();
            txtGenero.Clear();
        }

        private void Frm_Medicamentos_Load(object sender, EventArgs e)
        {
            dgvProduto.DataSource = Produtobll.Listar();
        }

        private void dgvMedicamentos_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            //Quando o usuário clicar em um registro da lista, os dados serão preenchidos
            txtId.Text = dgvProduto.Rows[e.RowIndex].Cells[0].Value.ToString();
            txtNome.Text = dgvProduto.Rows[e.RowIndex].Cells[1].Value.ToString();
            txtGenero.Text = dgvProduto.Rows[e.RowIndex].Cells[2].Value.ToString();
        }

        private void dgvMedicamentos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
